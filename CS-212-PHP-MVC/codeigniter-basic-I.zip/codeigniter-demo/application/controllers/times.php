<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Times extends CI_Controller {

	public function index()
	{
		$this->load->view('date_time');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/date_time.php */