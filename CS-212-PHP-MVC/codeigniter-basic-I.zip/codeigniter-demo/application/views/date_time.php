<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Date and Time | CodeIgniter Demo</title>

	<style type="text/css">

	::selection{ background-color: #E13300; color: white; }
	::moz-selection{ background-color: #E13300; color: white; }
	::webkit-selection{ background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}
	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}
	h1 {
		color: #444;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}
	#container {
		text-align: center;
		margin: 20px auto;
		width: 960px;
	}
	#date-time-block {
		border: 1px solid #D0D0D0;
		margin: 20px auto;
		padding: 20px;
		width: 500px;
	}

	</style>
</head>
<body>

<div id="container">
	<h1>The Current Time and Date is</h1>
	<div id="date-time-block">
		<p><?php 
		date_default_timezone_set("America/Detroit"); ?></p>
		<p><?php echo date("M j, Y"); ?></p>
		<p><?php echo date("g:i A"); ?></p>
	</div>
</div>

</body>
</html>