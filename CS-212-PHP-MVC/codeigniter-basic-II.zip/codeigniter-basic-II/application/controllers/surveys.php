<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Surveys extends CI_Controller {

	public function index()
	{
		$this->load->view('survey_form');
	}
	public function process_form()
	{

		// Create a counter and set it in the session's user data
        $counter = $this->session->userdata('counter');
        $this->session->set_userdata('counter', $counter + 1);

        // Create a message and set it in the session's flash data
		// $message = "<div class='message'>Thanks for submitting this form! You've submitted this form " . $counter . " times.</div>"; 
		// $this->session->set_flashdata($message);
		
		// Create an array that stores the post values from the survey form
		$survey = array(
			'name' => $this->input->post('name'),
			'location' => $this->input->post('location'),
			'favorite_language' => $this->input->post('favorite_language'),
			'comment' => $this->input->post('comment')
		);
			
		// Set the 		
		$this->session->set_flashdata($survey);

        redirect('/result', $this->session->flashdata('message', 'survey'));	
	}
	public function result()
	{

		$this->load->view('result');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/surveys.php */