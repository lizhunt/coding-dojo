<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="row">
    	<h1>Survey Form</h1>
    	<form action="/surveys/process_form" method="post">
    		<fieldset>
    			<legend>Please fill out the information below.</legend>
    			<label>Your Name: <input type="text" name="name"></label>
    			<label>Dojo Location: 
    				<select name="location">
    					<option>Seattle</option>
    					<option>Silicon Valley</option>
    					<option>Los Angeles</option>
    					<option>Remote</option>
    				</select>	
    			</label>
    			<label>Favorite Language: 
    				<select name="favorite_language">
    					<option>Javascript</option>
    					<option>PHP</option>
    					<option>Python</option>
    				</select>	
    			</label>
    			<label class="vertical-align-top">Comment (optional): 
    				<textarea class="vertical-align-top" name="comment"></textarea>
    			</label>	
    			<button type="submit">Submit</button>
    		</fieldset>
    	</form>	
    </div>	
</body>
</html>