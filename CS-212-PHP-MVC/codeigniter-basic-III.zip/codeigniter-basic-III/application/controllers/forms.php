<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forms extends CI_Controller {

	public function index()
	{
		$this->load->view('form');
	}
	public function generate_random_string()
	{

		// Create variables for generating a random string of 14 characters
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$characters_length = strlen($characters);
		$random_string = '';
		
		// Run through the length of characters set in the function and return a random string
		for($i = 0; $i < 14; $i++) {
    		$random_string .= $characters[rand(0, $characters_length - 1)];
		}

		// Temporarily set the data to show the random string
		$this->session->set_flashdata('random_string', $random_string);	

		// Create a counter and set it in the session user data
        $counter = $this->session->userdata('counter');
        $this->session->set_userdata('counter', $counter + 1);

        // This reloads page and uses a passed argument
        // $this->load->view('form', array('random_string'=>$random_string));

        // This uses flashdata!
        redirect('/');
			
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/surveys.php */