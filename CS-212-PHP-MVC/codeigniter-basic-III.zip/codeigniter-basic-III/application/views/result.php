<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Result — Survey Form | Codeigniter Basic II</title>
	<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
	<div class="row first">
		<h2>Submitted Information</h2>
		<hr />
		<?php 
			// var_dump($this->session->userdata);
		?>	
		<div class="message win">
			<?php 
				echo "<p>Thank'ee! You've submitted this form <strong>" . $this->session->userdata('counter') . "</strong> times.</p>"; 
			?>
		</div>
		<table id="results">
			<tr>
				<td class="item text-align-right"><strong>Name:</strong></td>
				<td><?php echo $this->session->flashdata('name'); ?></td>
			</tr>
			<tr>
				<td class="item text-align-right"><strong>Dojo Location:</strong></td>
				<td><?php echo $this->session->flashdata('location'); ?></td>
			</tr>
			<tr>
				<td class="item text-align-right"><strong>Favorite Laguage:</strong></td>
				<td><?php echo $this->session->flashdata('favorite_language'); ?></td>
			</tr>
			<tr>
				<td class="item text-align-right"><strong>Comment:</strong></td>
				<td><?php echo $this->session->flashdata('comment'); ?></td>
			</tr>	
		</table>
	</div>	
</body>
</html>