<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Products extends CI_Controller {

	public function index()
	{
		echo "<h1>This is the Products controller!</h1>";
	}
	public function show ($id1)
	{
		echo "<p>" . $id1 . "</p>";
			
	}
	public function edit ($id1)
	{
		echo "<p>" . $id1 . "</p>";
			
	}

}

/* End of file products.php */
/* Location: ./application/controllers/products.php */