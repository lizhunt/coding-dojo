<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sessions extends CI_Controller {

	public function index()
	{
		echo "<h1>This is the Sessions controller!</h1>";
	}
	public function new_session($string)
	{
		echo "<p>" . $string . "</p>";
			
	}
	public function logoff()
	{
		$this->session->sess_destroy();
		echo "<p> Thank you, you have logged off. </p>";
	}


}

/* End of file sessions.php */
/* Location: ./application/controllers/sessions.php */