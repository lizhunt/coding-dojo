<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users extends CI_Controller {

	public function index()
	{
		echo "<h1>This is the Users controller!</h1>";
	}
	public function new_user ($name)
	{
		echo "<p>" . $name . "</p>";
			
	}

}

/* End of file users.php */
/* Location: ./application/controllers/users.php */