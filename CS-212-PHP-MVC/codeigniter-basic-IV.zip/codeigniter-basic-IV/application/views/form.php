<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="row">
    	<h1>Random Word Generator</h1>
        <?php 
            // var_dump($this->session->flashdata);
            echo "<p class='text-align-center'>Attempt <strong>" . $this->session->userdata('counter') ."</strong></p>";
        ?>    
        <div id="random-string">
            <?php
                if(isset($random_string))
                 {
                    echo $random_string;
                 }  

                 echo $this->session->flashdata('random_string'); 
            ?>
        </div>    
    	<form action="/forms/generate_random_string" method="post">	
    		<button type="submit">Generate</button>
    	</form>	
    </div>	
</body>
</html>