<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Games extends CI_Controller {

	public function index()
	{
		$this->load->view('gold_game');
	}
	// Process gold/money in the game
	public function process_money()
	{

		date_default_timezone_set("America/New_York");
		$timestamp = date("F jS, Y g:i:s a T");

		if(!$this->session->userdata('activities'))
		{
			$this->session->set_userdata('activities', array());
		}

		// If the total gold value hasn't already been set , 
		if(!$this->session->userdata('total_gold_value'))
		{
			$this->session->set_userdata('total_gold_value', 0);
		}	

		// Specific actions for 'Farm'	
		if($this->input->post('action') == 'entered_farm')
		{
			$gold_submitted = rand(10,20);
			
			$total_gold_value = $this->session->userdata('total_gold_value');
			$this->session->set_userdata('total_gold_value', $total_gold_value + $gold_submitted);

			$activities = $this->session->userdata('activities');
			$activities[] = "<p class='gold-earned'>You have entered a <strong>farm</strong> and earned " . $gold_submitted . " gold coins. <span>" . $timestamp . "</span><p>";
			$this->session->set_userdata('activities', $activities);
		}	

		// Specific actions for 'Cave'	
		if($this->input->post('action') == 'entered_cave')
		{
			$gold_submitted = rand(5,10);
			
			$total_gold_value = $this->session->userdata('total_gold_value');
			$this->session->set_userdata('total_gold_value', $total_gold_value + $gold_submitted);
			
			$activities = $this->session->userdata('activities');
			$activities[] = "<p class='gold-earned'>You have entered a <strong>cave</strong> and earned " . $gold_submitted . " gold coins. <span>" . $timestamp . "</span><p>";			
			$this->session->set_userdata('activities', $activities);		
		}

		// Specific actions for 'House'	
		if($this->input->post('action') == 'entered_house')
		{
			$gold_submitted = rand(2,5);
			
			$total_gold_value = $this->session->userdata('total_gold_value');
			$this->session->set_userdata('total_gold_value', $total_gold_value + $gold_submitted);
			
			$activities = $this->session->userdata('activities');
			$activities[] = "<p class='gold-earned'>You have entered a <strong>house</strong> and earned " . $gold_submitted . " gold coins. <span>" . $timestamp . "</span><p>";
			$this->session->set_userdata('activities', $activities);		
		}

		// Specific actions for 'Casino'	
		if($this->input->post('action') == 'entered_casino')
		{
			$gold_submitted = rand(-50,50);
			
			$total_gold_value = $this->session->userdata('total_gold_value');
			$this->session->set_userdata('total_gold_value', $total_gold_value + $gold_submitted);

			$activities = $this->session->userdata('activities');

			if($gold_submitted > 0)
			{
				$activities[] = "<p class='gold-earned'>You have entered a <strong>casino</strong> and earned " . $gold_submitted . " gold coins. <span>" . $timestamp . "</span><p>";
			}
			else
			{
				$activities[] = "<p class='gold-lost'>You have entered a <strong>casino</strong> and lost " . $gold_submitted . " gold coins. ...Ouch!<span>" . $timestamp . "</span><p>";
			}
			$this->session->set_userdata('activities', $activities);
		}
		
		redirect('/');	
	}
	// Reset the session data in the game
	public function reset()
	{
		if($this->input->post('action') == 'reset')
		{
			$this->session->unset_userdata('activity');
			$this->session->sess_destroy();
		}

		redirect('/');
	}	

}

/* End of file games.php */
/* Location: ./application/controllers/games.php */