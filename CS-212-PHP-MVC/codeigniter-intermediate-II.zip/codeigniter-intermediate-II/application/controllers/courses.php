<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Courses extends CI_Controller {

	public function index()
	{
        // $this->output->enable_profiler(TRUE); //enables the profiler
        $this->load->model("Course"); 
        $courses = $this->Course->get_all_courses();  
        $this->load->view('add_courses', array('courses' => $courses));
	}
	public function show($id)
    {   
        $this->load->model("Course");
        $course = $this->Course->get_course_by_id($id);
        var_dump($course);
    }
    public function create()
    {
        $this->load->model("Course");
        
        $course = array(
            "course_name" => $this->input->post('course_name'),
            "description" => $this->input->post('description')
        );
        
        $course_name = $this->input->post('course_name');

        if(isset($course_name))
        {
            if(strlen($course_name) >= 15)
            {    
                $add_course = $this->Course->add_course($course);

                if($add_course === TRUE)
                {
                    $win = "<div class='message win'><p>Your course was added successfully!</p></div>";
                    $this->session->set_flashdata('message', $win);   
                } 
            }
            else
            {
                $fail = "<div class='message fail'><p>Oops! Your course name should have at least 15 characters.</p></div>";
                $this->session->set_flashdata('message', $fail);   
            }    
        }     

        redirect('/', $this->session->flashdata('message'));
    }
    public function destroy($course_id)
    {
        //Load up the Course model
        $this->load->model("Course");

        // Grab the id of selected course
        $course = $this->Course->get_course_by_id($course_id);

        // Before course is deleted from database, direct user to the "Are you sure?" prompt
        $this->load->view('prompt', array('course' => $course));
    }
    public function destroy_confirm($course_id)
    {
        //Load up the Course model
        $this->load->model("Course");

        // Set up our delete as a variable in order to confirm if it's true or not
        $delete_course = $this->Course->delete_course($course_id);

        //If user selects "Yes, remove this course.”, remove course from view, redirect and display confirmation message (flash data)
        if($delete_course === TRUE)
        {
            $win = "<div class='message win'><p>Your course was successfully removed.</p></div>";
            $this->session->set_flashdata('message', $win);

            redirect('/', $this->session->flashdata('message'));
        }   
        // Otherwise, just redirect to the index 
        else
        {
            redirect('/'); 
        }      
    }

}

/* End of file courses.php */
/* Location: ./application/controllers/courses.php */