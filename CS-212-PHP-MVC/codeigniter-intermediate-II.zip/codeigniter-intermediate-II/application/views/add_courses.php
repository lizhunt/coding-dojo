<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Coding Dojo | CS 212 &mdash; PHP &amp; MVC | Intermediate Assignment II</title>
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
        <div class="row first">
            <h1>Add a New Course</h1>
            <?php echo $this->session->flashdata('message'); ?> 
            <form action='courses/create' method='post'>
                <input type="hidden" name="action" value="add_course">
                <label>Name</label> 
                <input type="text" name="course_name"/>
                <label>Description</label> 
                <textarea name="description"></textarea>  
                <button class="submit display-block" type='submit'>Add</button>
            </form>
        </div>
        <div class="row">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Course Name</th>
                    <th>Description</th>
                    <th>Date Added</th>
                    <th>Action</th>
                </tr>
                <?php 

                if(isset($courses)) 
                { 
                    foreach($courses as $row)
                    {
                        
                        echo "<tr>";
                        foreach($row as $course)
                        {
                            echo "<td>" . $course . "</td>";
                        }   
                ?>     
                        <td><a href='/destroy/<?= $row['id'] ?>' class="delete">Remove</a></td>
                       </tr>
             <?php  }    
                } ?>      
            </table>    
        </div>  
    </body>
</html>