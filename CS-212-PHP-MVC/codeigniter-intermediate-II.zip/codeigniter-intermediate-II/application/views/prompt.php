<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Coding Dojo | CS 212 &mdash; PHP &amp; MVC | Intermediate Assignment II</title>
        <link rel="stylesheet" href="/assets/css/style.css">
    </head>
    <body>
        <div class="row first text-align-center clearfix">
            <h2 class="text-align-center">Are you sure you want to delete this course?</h2> 
            <?php var_dump($course); ?>

            <?php 

                if(isset($course)) 
                { 

                    foreach($course as $details)
                    {
                        // echo "<p>" . $details['course_name'] . "</p>";
                        echo "<p>" . $details . "</p>";
                    }   
            ?>     
                    <a class="button cancel display-inline-block vertical-align-middle" href='/'>Nope, nevermind!</a>    
                    <a class="button confirm display-inline-block vertical-align-middle delete" href="/destroy_confirm/<?= $course['id'] ?>">Yes, I want to delete this course.</a>
            <?php } ?>
        </div>    
    </body>
</html>