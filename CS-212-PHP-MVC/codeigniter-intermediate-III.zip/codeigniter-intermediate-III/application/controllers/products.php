<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Products extends CI_Controller {

	public function index()
	{
        // $this->output->enable_profiler(TRUE); //enables the profiler
        $this->load->model("Product"); 
        $products = $this->Product->get_all_products();  
        $this->load->view('all_products', array('products' => $products));
	}
	public function show($id)
    {   
        $this->load->model("Product");
        $product = $this->Product->get_product_by_id($id);
        $this->load->view('view_product', array('product' => $product));
        // var_dump($product);
    }
    public function create_index()
    {
        $this->load->model("Product");
        $this->load->view('add_product');
    }
    public function create()
    {    
        $this->load->model("Product");

        $product = array(
            "name" => $this->input->post('name'),
            "description" => $this->input->post('description'),
            "price" => $this->input->post('price')
        );
        
        $product_name = $this->input->post('name');

        if(isset($product_name))
        {
  
            $add_product = $this->Product->add_product($product);

            if($add_product === TRUE)
            {
                $win = "<div class='message win'><p>Your product was added successfully!</p></div>";
                $this->session->set_flashdata('message', $win); 
                redirect('/', $this->session->flashdata('message'));  
            } 
            else
            {
                $fail = "<div class='message fail'><p>Oops! Your product name shouldn't be empty, and/or have at least 15 characters.</p></div>";
                $this->session->set_flashdata('message', $fail);
                redirect('/create_index');   
            }    
        }     
    }
    public function edit($id)
    {
        $this->load->model("Product");
        $product = $this->Product->get_product_by_id($id);
        $this->load->view('edit_product', array('product' => $product));
    }
    public function update($id)
    {
        $this->load->model("Product");

        $product = $this->input->post();

        $product['id'] = $id;

        $this->Product->update_product($product);
        redirect('/');
    }
    public function destroy($product_id)
    {
        $this->load->model("Product");
        $product = $this->Product->get_product_by_id($product_id);
        $this->load->view('prompt', array('product' => $product));
    }
    public function destroy_confirm($product_id)
    {
        $this->load->model("Product");
        $delete_product = $this->Product->delete_product($product_id);

        if($delete_product === TRUE)
        {
            $win = "<div class='message win'><p>Your product was successfully removed.</p></div>";
            $this->session->set_flashdata('message', $win);
            redirect('/', $this->session->flashdata('message'));
        }   
        else
        {
            redirect('/'); 
        }      
    }

}

/* End of file products.php */
/* Location: ./application/controllers/products.php */