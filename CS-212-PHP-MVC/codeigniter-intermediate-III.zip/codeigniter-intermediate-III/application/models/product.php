<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product extends CI_Model 
{
     function get_all_products()
     {
         return $this->db->query("SELECT id, name, description, price FROM products ORDER BY created_at DESC")->result_array();
     }
     function get_product_by_id($product_id)
     {
         return $this->db->query("SELECT * FROM products WHERE id = ?", array($product_id))->row_array();
     }
     function add_product($product)
     {
         $query = "INSERT INTO Products (name, description, price, created_at) VALUES (?,?,?,?)";
         $values = array($product['name'], $product['description'], $product['price'], date("Y-m-d, H:i:s")); 
         return $this->db->query($query, $values);
     }
     function update_product($product)
     {
        // $id = $product['id'];
        // $name = $product['name'];
        // $description = $product['description'];
        // $price = $product['price'];

        $query = "UPDATE products SET name = ?, description = ?, price = ?, updated_at = NOW() WHERE id = ?";
        $values = array($product['name'], $product['description'], $product['price'], $product['id']);
        return $this->db->query($query, $values);
     }
     function delete_product($product_id)
     {
        return $this->db->query("DELETE FROM products WHERE id = ?", array($product_id));
     }
}

/* End of file product.php */
/* Location: ./application/models/product.php */