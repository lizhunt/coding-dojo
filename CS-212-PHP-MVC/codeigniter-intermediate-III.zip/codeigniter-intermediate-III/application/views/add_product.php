<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Add a New Product | Coding Dojo | CS 212 &mdash; PHP &amp; MVC | Intermediate Assignment III</title>
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
        <div class="row first">
            <h1>Add a New Product</h1>
            <?php echo $this->session->flashdata('message'); ?> 
            <form action='products/create' method='post'>
                <input type="hidden" name="action" value="add_product">
                <label>Name</label> 
                <input type="text" name="name"/>
                <label>Description</label> 
                <input class="description" name="description"/> 
                <label>Price</label> 
                <input type="number" name="price"/> 
                <button class="submit display-block" type='submit'>Create</button>
            </form>
            <p><a href="/">Back</a></p>
        </div>  
    </body>
</html>