<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>All Products | Coding Dojo | CS 212 &mdash; PHP &amp; MVC | Intermediate Assignment III</title>
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
        <div class="row first">
            <h1>Products</h1>
            <?php echo $this->session->flashdata('message'); ?> 
            <table>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
                <?php if(isset($products)) { foreach($products as $row) { ?><!-- Begin if statement and first foreach loop -->  
                <tr>
                    <?php foreach($row as $product) { ?><!-- Begin second foreach loop -->
                    <td><?php echo $product; ?></td>
                    <?php } ?><!-- End second foreach loop -->   
                    <td style="width: 20%;">
                        <p><a href="/show/<?= $row['id'] ?>">Show</a> | <a href="/edit/<?= $row['id'] ?>">Edit</a> | <a href='/destroy/<?= $row['id'] ?>' class="delete">Remove</a></p>
                    </td>
                </tr>
                <?php } } ?> <!-- End if statement and first foreach loop -->      
            </table>
            <p><a href="/create_index">Add a New Product</a></p>    
        </div>  
    </body>
</html>