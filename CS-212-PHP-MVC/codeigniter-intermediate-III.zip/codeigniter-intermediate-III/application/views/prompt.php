<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Coding Dojo | CS 212 &mdash; PHP &amp; MVC | Intermediate Assignment II</title>
        <link rel="stylesheet" href="/assets/css/style.css">
    </head>
    <body>
        <div class="row first clearfix">
            <h2>Are you sure you want to delete this product?</h2>  
            <?php 
                if(isset($product)) 
                { 
                    echo "<p><strong>Name: </strong>" . $product['name'] . "</p>";
                    echo "<p><strong>Description: </strong>" . $product['description'] . "</p>";
                    echo "<p><strong>Price:</strong> $" . $product['price'] . "</p>";
                }      
            ?>
            <a class="button cancel display-inline-block vertical-align-middle" href='/'>Nope, nevermind!</a>    
            <a class="button confirm display-inline-block vertical-align-middle delete" href="/destroy_confirm/<?= $product['id'] ?>">Yes, I want to delete this product.</a>
        </div>    
    </body>
</html>