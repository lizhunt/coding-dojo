<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>View Product | Coding Dojo | CS 212 &mdash; PHP &amp; MVC | Intermediate Assignment III</title>
        <link rel="stylesheet" href="/assets/css/style.css">
    </head>
    <body>
        <div class="row first">
            <h1>View Product</h1>
            <?php 
                if(isset($product)) 
                { 
                    echo "<p><strong>Name: </strong>" . $product['name'] . "</p>";
                    echo "<p><strong>Description: </strong>" . $product['description'] . "</p>";
                    echo "<p><strong>Price:</strong> $" . $product['price'] . "</p>";
                } 
            ?>  
            <p><a href="/">Edit</a> | <a href="/">Back</a></p>    
        </div>  
    </body>
</html>