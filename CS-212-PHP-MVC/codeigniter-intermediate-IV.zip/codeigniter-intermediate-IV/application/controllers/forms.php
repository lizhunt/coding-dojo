<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forms extends CI_Controller {
    
    public function register_form()
    {

        // Load up the helpers and library for form validations
        $this->load->helper('form');
        $this->load->library('form_validation');

        // Set error delimeters
        $this->form_validation->set_error_delimiters('<div class="message fail"><p>', '</p></div>');

        // Set up form validation rules 
        $this->form_validation->set_rules("first_name", "First Name", "trim|required");
        $this->form_validation->set_rules("last_name", "Last Name", "trim|required");
        $this->form_validation->set_rules("email", "First Name", "trim|required|valid_email");
        $this->form_validation->set_rules("password", "Password", "trim|required|min_length[8]|matches[confirm_password]|md5");
        $this->form_validation->set_rules("confirm_password", "Confirm Password", "trim|required");
        
        // Set up error and success actions when a form is submitted
        if($this->form_validation->run() === FALSE)
        {    
            // If there are specific errors, throw them
            $this->form_validation->set_message('required', 'Oops! Looks like you are missing some required fields!');
            $this->form_validation->set_message('valid_email', 'Please enter a valid email address.');
            $this->form_validation->set_message('min_length[8]', 'Sorry, but your password needs to be at least 8 characters long. Its for your protection!');
            $this->form_validation->set_message('matches[confirm_password]', 'Oops! Looks like your passwords do not match.');
            
            // Load view
            $this->load->view('login_or_register');

        }
        else
        {
            // Otherwise, if there are no errors, redirect to another class for creating user in the database
            redirect('/users/create_user');
        }

    }    
    
    public function login_form()
    {
        // Load up the helpers and library for form validations
        $this->load->helper('form');
        $this->load->library('form_validation');

        // Set error delimeters
        $this->form_validation->set_error_delimiters('<div class="message fail"><p>', '</p></div>');

        // Set up form validation rules 
        $this->form_validation->set_rules("email", "First Name", "trim|required");
        $this->form_validation->set_rules("password", "Password", "trim|required|md5");
        
        // Set up error and success actions when a form is submitted
        if($this->form_validation->run() === FALSE)
        {    
            // If there are specific errors, throw them
            $this->form_validation->set_message('required', 'Oops! Looks like you are missing some required fields!');
            
            // Load view
            $this->load->view('login_or_register');
        }
        else
        {
            // Otherwise, if there are no errors, redirect to creating a user in the database
            redirect('/users/login_user');
        } 
    }      
     

}

/* End of file form.php */
/* Location: ./application/controllers/form.php */