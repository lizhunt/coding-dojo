<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users extends CI_Controller {

    //Direct user to 'login_or_register' page
	public function index()
	{
        $this->load->helper('form');
        $this->load->library('form_validation');
        
        $this->load->view('login_or_register');
	}

    // Set up rules for logging in, which will use the session class
    public function login_user()
    {
        $email = $this->input->post('email');
        $password = md5($this->input->post('password'));
        
        $this->load->model('User');
        $user = $this->User->get_user_by_email($email);

        if($user && $user['password'] == $password)
        {
            $user_info = array(
               'id' => $user['id'],
               'email_address' => $user['email_address'],
               'name' => $user['first_name'].' '.$user['last_name'],
               'is_logged_in' => TRUE
            );
            
            $this->session->set_userdata($user_info);


            if($this->session->userdata('is_logged_in') === TRUE)
            {
                $this->load->model("User");
                $user = $this->User->get_user_by_email($email);
                $this->load->view('user_profile', array('user' => $user));
            }    
            else
            {
                redirect("/users/login_user"); 
            }

        }
        else
        {
            $fail = "<div class='message fail'><p>Sorry, we had trouble logging you in. Did you enter the correct email/password?</p></div>";
            $this->session->set_flashdata("message", $fail);
            redirect('/', 'message');
        }
    }

    // When a new user registers, create them and add them to the database
    public function create_user()
    {    

        // Load up the helpers and library for form validations
        $this->load->helper('form');
        $this->load->library('form_validation');

        // Set error delimeters
        $this->form_validation->set_error_delimiters('<div class="message fail"><p>', '</p></div>');

        // Set up form validation rules 
        $this->form_validation->set_rules("first_name", "First Name", "trim|required");
        $this->form_validation->set_rules("last_name", "Last Name", "trim|required");
        $this->form_validation->set_rules("email", "First Name", "trim|required|valid_email");
        $this->form_validation->set_rules("password", "Password", "trim|required|min_length[8]|matches[confirm_password]|md5");
        $this->form_validation->set_rules("confirm_password", "Confirm Password", "trim|required");
        
        // Set up error and success actions when a form is submitted
        if($this->form_validation->run() === FALSE)
        {    
            // If there are specific errors, throw them
            $this->form_validation->set_message('required', 'Oops! Looks like you are missing some required fields!');
            $this->form_validation->set_message('valid_email', 'Please enter a valid email address.');
            $this->form_validation->set_message('min_length[8]', 'Sorry, but your password needs to be at least 8 characters long. Its for your protection!');
            $this->form_validation->set_message('matches[confirm_password]', 'Oops! Looks like your passwords do not match.');
            
            // Load view
            $this->load->view('login_or_register');

        }
        else
        {
            // Otherwise, if there are no errors, redirect to another class for creating user in the database
            
            // var_dump($this->input->post());
            // die();

            // Load up the model
            $this->load->model("User");

            // Set up an associative array for storing form values in the database   
            $user = array(
                'first_name' => $this->input->post('first_name'),
                'last_name' => $this->input->post('last_name'),
                'email' => $this->input->post('email'),
                'password' => $this->input->post('password')
            );

            // Set the function from the User model
            $this->User->add_user($user);

            redirect('/');
        }


        // // If the requested model method returns true, redirect to same page with success message
        // if(isset($user_name))
        // {
        //     $add_user = $this->user->add_user($user);

        //     if($add_user === TRUE)
        //     {
        //         $win = "<div class='message win'><p>Hey, thanks for registering! Go forth, have fun, be safe!</p></div>";
        //         $this->session->set_flashdata('message', $win);
        //         redirect('/', 'message');  
        //     }
        //     else
        //     {

        //     }    

        // }      

    }

    // If login is successful, direct the user to a simple profile page
    public function view_user()
    {
        if($this->session->userdata('is_logged_in') === TRUE)
        {
            $this->load->model("User");
            $user = $this->User->get_user_by_email($email);
            $this->load->view('user_profile', array('user' => $user));
        }    
        else
        {
            redirect("/users/login_user"); 
        }    
    }
    
    // Logout the user and redirect them to the login/registration page
    public function logout_user()
    {
        $this->session->sess_destroy();
        redirect("/users/index");   
    }

    // public function edit($id)
    // {
    //     $this->load->model("User");
    //     $user = $this->user->get_user_by_id($id);
    //     $this->load->view('edit_user', array('user' => $user));
    // }
    // public function update($id)
    // {
    //     $this->load->model("User");
    //     $user = $this->input->post();
    //     $user['id'] = $id;

    //     $this->user->update_user($user);
    //     redirect('/');
    // }

}

/* End of file users.php */
/* Location: ./application/controllers/users.php */