<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Model 
{
     function get_user_by_email($email)
     {
         return $this->db->query("SELECT * FROM users WHERE email_address = ?", array($email))->row_array();
     }
     function add_user($user)
     {
        // $password = $user['password'];
        // $salt = bin2hex(openssl_random_pseudo_bytes(22));
        // $encrypted_password = md5($password . '' . $salt);

        // var_dump($user);
        // die();

        $query = "INSERT INTO Users (first_name, last_name, email_address, password, created_at, updated_at) VALUES (?,?,?,?,?,?)";
        $values = array($user['first_name'], $user['last_name'], $user['email'], $user['password'], date("Y-m-d, H:i:s"), date("Y-m-d, H:i:s")); 
        
        return $this->db->query($query, $values);
     }
}

/* End of file user.php */
/* Location: ./application/models/user.php */