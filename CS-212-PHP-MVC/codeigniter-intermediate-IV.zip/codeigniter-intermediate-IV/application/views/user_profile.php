<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>User Profile | Coding Dojo | CS 212 &mdash; PHP &amp; MVC | Intermediate Assignment III</title>
        <link rel="stylesheet" href="/assets/css/style.css">
    </head>
    <body>
        <div class="row first">
            <h1>Welcome!</h1>
            <?php 
                if(isset($user)) 
                { 
                    echo "<p><strong>Name: </strong>" . $user['first_name'] . " " . $user['last_name'] . "</p>";
                    echo "<p><strong>Email: </strong>" . $user['email_address'] . "</p>";
                } 
            ?>  
            <p><a href="/">Logout</a></p>    
        </div>  
    </body>
</html>