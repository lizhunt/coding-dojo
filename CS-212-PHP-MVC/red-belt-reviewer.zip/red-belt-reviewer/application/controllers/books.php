<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Books extends CI_Controller {

    //Direct user to 'add_book_and_review' page
	public function index()
	{
        $this->load->model("Book");

        $this->load->helper('form');
        $this->load->library('form_validation');

        $books = $this->Book->get_all_books();
        
        $this->load->view('add_book_and_review', array('books' => $books));
	}
    // Add new audiobook to the database
    public function add_book_and_review()
    {    
        // Load up the CI helpers and library for form validations
        $this->load->helper('form');
        $this->load->library('form_validation');

        // Set error delimeters
        $this->form_validation->set_error_delimiters('<div class="message fail"><p>', '</p></div>');

        // Set up form validation rules 
        $this->form_validation->set_rules("title", "Title", "trim|required");
        $this->form_validation->set_rules("author", "Author", "trim|required");
        $this->form_validation->set_rules("narrator", "Narrator", "trim|required");
        $this->form_validation->set_rules("description", "Review", "trim|required");
        $this->form_validation->set_rules("rating", "Rating", "required");

        // Set up error and success actions when a form is submitted
        if($this->form_validation->run() === FALSE)
        {    
            // If there are specific errors, throw them
            $this->form_validation->set_message('required', 'Oops! Looks like you are missing some required fields!');
            
            // Load view
            $this->load->view('add_book_and_review');
        }
        else
        {
            // Load up the models
            $this->load->model("Book");
            $this->load->model("Review");

            $book['title'] = $this->input->post('title');
            $book['author'] = $this->input->post('author');
            $book['narrator'] = $this->input->post('narrator');
            $book['user_id'] = $this->session->userdata('id');

            $book_id = $this->Book->add_book($book);

            // Set up associative arrays for storing values in database and run methods
            $review['description'] = $this->input->post('description');
            $review['rating'] = $this->input->post('rating');
            $review['book_id'] = $book_id;
            $review['user_id'] = $this->session->userdata('id');

            $this->Review->add_review($review);

            // Success message
            $win = "<div class='message win'><p>Thanks for adding an audiobook and review!</p></div>";
            $this->session->set_flashdata('message', $win);

            // Redirect to the view
            redirect('/users/dashboard', 'message');
        }
    }
    // If submission of the review is successful, direct the user to a the book's profile page    
    public function view_book_and_reviews($book_id)
    {
        $this->load->model("Book");
        $this->load->model("Review");

        $book = $this->Book->get_book_by_id($book_id);
        $book_reviews = $this->Review->get_all_reviews_by_book($book_id);

        $this->load->view('book_profile', array('book' => $book, 'book_reviews' => $book_reviews));
    }

}

/* End of file books.php */
/* Location: ./application/controllers/books.php */