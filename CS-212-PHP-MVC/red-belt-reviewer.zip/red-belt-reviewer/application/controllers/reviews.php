<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reviews extends CI_Controller {

    // Add new review to the database
    public function create_review($book_id)
    {    
        // Load up the CI helpers and library for form validations
        $this->load->helper('form');
        $this->load->library('form_validation');

        // Set error delimeters
        $this->form_validation->set_error_delimiters('<div class="message fail"><p>', '</p></div>');

        // Set up form validation rules 
        $this->form_validation->set_rules("description", "Description", "trim|required");
        $this->form_validation->set_rules("rating", "Rating", "required");
        
        // Set up error and success actions when a form is submitted
        if($this->form_validation->run() === FALSE)
        {    
            // If there are specific errors, throw them
            $this->form_validation->set_message('required', 'Oops! Looks like you are missing some required fields!');
            
            // Load view
            // $this->load->view('dashboard');
        }
        else
        {
            // Load up the model
            $this->load->model("Book");
            $this->load->model("Review");


            // Set up an associative array for storing form values in the database   
            $review['description'] = $this->input->post('description');
            $review['rating'] = $this->input->post('rating');
            $review['book_id'] = $book_id;
            $review['user_id'] = $this->session->userdata('id');

            // Set the function from the Review model
            $this->Review->add_review($review);

            // Redirect to the view
            $book_reviews = $this->Review->get_all_reviews_by_book($book_id);
            $book = $this->Book->get_book_by_id($book_id);
            
            $this->load->view('book_profile', array('book_reviews' => $book_reviews, 'book' => $book));
        }     
    }
    // Delete the review
    public function destroy_review($review_id)
    {
        $this->load->model("Review");
        
        $delete_review = $this->Review->delete_review($review_id);

        if($delete_review === TRUE)
        {
            $win = "<div class='message win'><p>Your review was successfully removed.</p></div>";
            $this->session->set_flashdata('message', $win);
            redirect('/', 'message');
        }        
    }

}

/* End of file books.php */
/* Location: ./application/controllers/books.php */