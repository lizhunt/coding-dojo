<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users extends CI_Controller {

    //Direct user to 'login_or_register' page
	public function index()
	{
        $this->load->helper('form');
        $this->load->library('form_validation');

        if($this->session->userdata('is_logged_in') === TRUE)
        {
            redirect("/users/dashboard");
        }
        else
        {
            $this->load->view('login_or_register');   
        }    
	}
    // When a new user registers, create and add them to the database
    public function create_user()
    {    

        // Load up the CI helpers and library for form validations
        $this->load->helper('form');
        $this->load->library('form_validation');

        // Set error delimeters
        $this->form_validation->set_error_delimiters('<div class="message fail"><p>', '</p></div>');

        // Set up form validation rules 
        $this->form_validation->set_rules("name", "Name", "trim|required");
        $this->form_validation->set_rules("alias", "Alias", "trim|required");
        $this->form_validation->set_rules("email", "Email", "trim|required|valid_email");
        $this->form_validation->set_rules("password", "Password", "trim|required|min_length[8]|matches[confirm_password]|md5");
        $this->form_validation->set_rules("confirm_password", "Confirm Password", "trim|required");
        
        // Throw errors if the form submission fails to meet the validation rules
        if($this->form_validation->run() === FALSE)
        {    
            // If there are specific errors, throw them
            $this->form_validation->set_message('required', 'Oops! Looks like you are missing some required fields!');
            $this->form_validation->set_message('valid_email', 'Please enter a valid email address.');
            $this->form_validation->set_message('min_length[8]', 'Sorry, but your password needs to be at least 8 characters long. Its for your protection!');
            $this->form_validation->set_message('matches[confirm_password]', 'Oops! Looks like your passwords do not match.');
            
            // Load view
            $this->load->view('login_or_register');

        }
        else
        {
            // Load up the model
            $this->load->model("User");

            // Set up an associative array for storing form values in the database   
            $user = array(
                'name' => $this->input->post('name'),
                'alias' => $this->input->post('alias'),
                'email' => $this->input->post('email'),
                'password' => $this->input->post('password')
            );

            $user_name = $this->input->post('name');

            if(isset($user_name))
            {  
                // Set the function 
                $add_user = $this->User->add_user($user);;

                if($add_user === TRUE)
                {
                    // Redirect
                    $win = "<div class='message win'><p>Hey, thanks for registering! Go forth, have fun, be safe!</p></div>";
                    $this->session->set_flashdata('message', $win);
                    redirect('/', 'message');  
                } 
   
            }

        }

    }
        // Set up rules for logging in, which will use the session class
    public function login_user()
    {
        $email = $this->input->post('email');
        $password = md5($this->input->post('password'));
        
        $this->load->model('User');
        $user = $this->User->get_user_by_email($email);

        if($user && $user['password'] == $password)
        {
            $user_info = array(
               'id' => $user['id'],
               'name' => $user['name'],
               'alias' => $user['alias'],
               'email' => $user['email'],
               'is_logged_in' => TRUE
            );
            
            $this->session->set_userdata($user_info);   

            if($this->session->userdata('is_logged_in') === TRUE)
            {
                redirect("/users/dashboard");
            }    
            else
            {
                redirect("/users/login_user"); 
            }

        }
        else
        {
            $fail = "<div class='message fail'><p>Sorry, we had trouble logging you in. Did you enter the correct email/password?</p></div>";
            $this->session->set_flashdata("message", $fail);
            redirect('/', 'message');
        }
    }
    // Take user to dashboard if logged in
    public function dashboard()
    {
        $this->load->model("User");
        $this->load->model("Book");
        $this->load->model("Review");

        $recent_reviews = $this->Review->get_recently_reviewed_books();
        $all_books = $this->Book->get_all_books();

        $this->load->view('dashboard', array('recent_reviews' => $recent_reviews, 'all_books' => $all_books));
    }
    // If login is successful, direct the user to a simple profile page
    public function view_profile($user_id)
    {
        if($this->session->userdata('is_logged_in') === TRUE)
        {
            $this->load->model("User");
            $this->load->model("Review");

            //$user = $this->session->userdata('id');
            $books = $this->Review->get_all_reviews_by_user($user_id);

            $this->load->view('user_profile', array('books' => $books));
        }        
    }
    // If login is successful, direct the user to a simple profile page
    public function view_user($user_id)
    {
        $this->load->model("User");
        $this->load->model("Review");

        $user = $this->User->get_user_by_id($user_id);
        $books = $this->Review->get_all_reviews_by_user($user_id);
        
        $this->load->view('user_profile', array('user' => $user, 'books' => $books));      
    }
    // Logout the user and redirect them to the login/registration page
    public function logout_user()
    {
        $this->session->sess_destroy();
        redirect("/users/index");   
    }

    // Edit the user *** CURRENTLY NOT IN USE, NEEDS MODIFICATIONS
    public function edit_user($user_id)
    {
        $this->load->model("User");
        $user = $this->user->get_user_by_id($user_id);
        $this->load->view('edit_user', array('user' => $user));
    }
    // Update the user *** CURRENTLY NOT IN USE, NEEDS MODIFICATIONS
    public function update_user($user_id)
    {
        $this->load->model("User");
        $user = $this->input->post();
        $user['id'] = $user_id;

        $this->user->update_user($user);
        redirect('/');
    }
    // Delete the user *** CURRENTLY NOT IN USE, NEEDS MODIFICATIONS
    public function destroy_user($user_id)
    {
        $this->load->model("User");
        $user = $this->User->get_user_by_id($user_id);
        $this->load->view('prompt', array('user' => $user));
    }
    // Confirm deleting user from the databse *** CURRENTLY NOT IN USE, NEEDS MODIFICATIONS
    public function destroy_user_confirm($user_id)
    {
        $this->load->model("User");
        $delete_user = $this->User->delete_user($user_id);

        if($delete_user === TRUE)
        {
            $win = "<div class='message win'><p>Your account was successfully removed.</p></div>";
            $this->session->set_flashdata('message', $win);
            redirect('/', $this->session->flashdata('message'));
        }   
        else
        {
            redirect('/'); 
        }      
    }
}

/* End of file users.php */
/* Location: ./application/controllers/users.php */