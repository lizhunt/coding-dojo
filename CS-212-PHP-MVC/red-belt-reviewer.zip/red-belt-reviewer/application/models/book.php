<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Book extends CI_Model 
{
    function add_book($book)
    {
        $query = "INSERT INTO Books (title, author, narrator, user_id, created_at, updated_at) VALUES (?,?,?,?,?,?)";
        $values = array($book['title'], $book['author'], $book['narrator'], $book['user_id'], date("Y-m-d, H:i:s"), date("Y-m-d, H:i:s")); 

        $this->db->query($query, $values);
        
        return $this->db->insert_id();
    }
    function get_book_by_id($book_id)
    {
        return $this->db->query("SELECT * FROM books WHERE id = ?", array($book_id))->row_array();
    }
    function get_all_books()
    {
        return $this->db->query("SELECT * FROM books ORDER BY title ASC")->result_array();
    }    
}

/* End of file book.php */
/* Location: ./application/models/book.php */