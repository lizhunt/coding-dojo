<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Review extends CI_Model 
{
    function get_recently_reviewed_books()
    {
        return $this->db->query("SELECT * FROM reviews
                                LEFT JOIN books
                                ON books.id = reviews.book_id
                                LEFT JOIN users
                                ON reviews.user_id = users.id
                                ORDER BY reviews.created_at DESC
                                LIMIT 3")->result_array();                       
    }
    function get_all_books_with_reviews()
    {
        return $this->db->query("SELECT * FROM reviews
                                 LEFT JOIN books
                                 ON books.id = reviews.book_id
                                 ORDER BY books.title ASC")->result_array();
    }
    function get_all_reviews_by_user($user_id)
    {
        return $this->db->query("SELECT * FROM reviews
                  LEFT JOIN books
                  ON books.id = reviews.book_id
                  LEFT JOIN users
                  ON reviews.user_id = users.id
                  WHERE users.id = ?", array($user_id))->result_array();                        
    }
    function get_all_reviews_by_book($book_id)
    {
        return $this->db->query("SELECT reviews.id as review_id, reviews.user_id, reviews.rating, reviews.description, reviews.created_at, users.alias, creator.id as creator_id, creator.alias as creator_alias 
                                FROM reviews
                                LEFT JOIN books
                                ON books.id = reviews.book_id
                                LEFT JOIN users
                                ON reviews.user_id = users.id
                                LEFT JOIN users as creator
                                ON books.user_id = creator.id
                                WHERE books.id = ?", array($book_id))->result_array();                       
    }
    function add_review($review)
    {
        $query = "INSERT INTO Reviews (description, rating, book_id, user_id, created_at, updated_at) VALUES (?,?,?,?,?,?)";
        $values = array($review['description'], $review['rating'], $review['book_id'], $review['user_id'], date("Y-m-d, H:i:s"), date("Y-m-d, H:i:s")); 
        return $this->db->query($query, $values);
    }
    function delete_review($review_id)
     {
        return $this->db->query("DELETE FROM reviews WHERE id = ?", array($review_id));
     }
}

/* End of file review.php */
/* Location: ./application/models/review.php */