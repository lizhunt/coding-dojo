<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Model 
{
    // Add a user to the database
    function add_user($user)
    {
        $query = "INSERT INTO Users (name, alias, email, password, created_at, updated_at) VALUES (?,?,?,?,?,?)";
        $values = array($user['name'], $user['alias'], $user['email'], $user['password'], date("Y-m-d, H:i:s"), date("Y-m-d, H:i:s")); 
        
        return $this->db->query($query, $values);
    }
    // Get all users
    function get_all_users()
     {
         return $this->db->query("SELECT name, alias FROM users ORDER BY created_at DESC")->result_array();
     }
     // For signing in a user
    function get_user_by_email($email)
    {
        return $this->db->query("SELECT * FROM users WHERE email = ?", array($email))->row_array();
    }
    // Get a user and display their account information
    function get_user_by_id($user_id)
    {
        return $this->db->query("SELECT * FROM users WHERE id = ?", array($user_id))->row_array();
    }
    // Update user profile  *** NOT IN USE, NEEDS MODIFICATIONS
    function update_user($user)
    {
        $query = "UPDATE Users SET name = ?, alias = ?, email = ?, updated_at = NOW() WHERE id = ?";
        $values = array($user['name'], $user['alias'], $user['email'], $user['id']);
        return $this->db->query($query, $values);
    }
    // Delete user profile  *** NOT IN USE, NEEDS MODIFICATIONS
    function delete_user($user_id)
    {
        return $this->db->query("DELETE FROM Users WHERE id = ?", array($user_id));
    }
}

/* End of file user.php */
/* Location: ./application/models/user.php */