<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Add an Audiobook and Review, GoodListens | Coding Dojo | Red Belt Reviewer</title>
        <link rel="stylesheet" href="/assets/css/style.css">
    </head>
    <body>
        <div id="header" class="clearfix">
            <h2 id="logo" class="float-left display-inline-block vertical-align-middle"><a href="/users/index">GoodListens</a></h2>
            <ul class="float-right display-inline-block vertical-align-middle">
                <li><a href="/">Home</a></li>
                <?php $thisUser = $this->session->userdata('id'); ?> 
                <li><a href='/users/view_profile/<?= $thisUser ?>'>View Profile</a></li>
                <li class="last"><a href="/users/logout_user">Logout</a></li>
            </ul>
            <div class="clearfix"></div>
        </div>
        <div id="main" class="padding-top-twenty">
            <div class="row padding-bottom-forty clearfix">
                <h1 class="text-align-center">Add a New Audiobook and Review</h1>
                
                <?php echo validation_errors(); ?>
                
                <div id="book-review-box" class="form-container margin-auto">
                    <form class="clearfix" action="/books/add_book_and_review" method="post">
                        <input type="hidden" name="action" value="">
                        <p>
                            <label>Title <span>*</span>:</label> 
                            <input type="text" name="title">
                        </p>
                        <p>
                            <label>Author <span>*</span>:</label>
                            <?php if(isset($books)) { ?>

                                Select from the list
                                <select>
                                <?php foreach($books as $book) { ?>
                                    <option name="author"><?= $book['author'] ?></option>
                                <?php } ?>
                                </select>
                                or 
                            <?php } ?>
                            <input type="text" name="author" placeholder="Add a New Author">
                        </p>
                        <p>
                            <label>Narrator <span>*</span>:</label>
                            <?php if(isset($books)) { ?>

                                Select from the list
                                <select>    
                                <?php foreach($books as $book) { ?>
                                    <option name="narrator"><?= $book['narrator'] ?></option>
                                <?php } ?>
                                </select>
                                or 
                            <?php } ?>
                            <input type="text" name="narrator" placeholder="Add a New Narrator">
                        </p>
                        <p>
                            <label>Review:</label> 
                            <textarea name="description"></textarea>
                        </p>
                        <p>
                            <label>Rating:</label> 
                            <input type="number" name="rating" min="1" max="5">
                            (from 1 to 5)
                        </p>
                        <button class="submit" type='submit'>Add Audiobook and Review</button>
                    </form> 
                </div>

            </div>       
        </div>  
    </body>
</html>