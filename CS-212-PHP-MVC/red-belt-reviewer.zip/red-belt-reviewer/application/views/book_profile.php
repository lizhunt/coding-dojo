<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Book Profile, GoodListens | Coding Dojo | Red Belt Reviewer</title>
        <link rel="stylesheet" href="/assets/css/style.css">
    </head>
    <body>
        <div id="header" class="clearfix">
            <h2 id="logo" class="float-left display-inline-block vertical-align-middle"><a href="/">GoodListens</a></h2>
            <ul class="float-right display-inline-block">
                <li><a href="/users/index">Home</a></li>
                <?php $thisUser = $this->session->userdata('id'); ?> 
                <li><a href='/users/view_profile/<?= $thisUser ?>'>View Profile</a></li>
                <li><a href="/books/index">Add New Audiobook and Review</a></li>
                <li class="last"><a href="/users/logout_user">Logout</a></li>
            </ul>
            <div class="clearfix"></div>
        </div>
        <div id="main" class="padding-top-twenty">
            <div class="row clearfix">
                <?php if(isset($book)) { ?> 
                    <h1><?= $book['title'] ?></h1>
                    <p><strong>Author(s): </strong><?= $book['author'] ?></p>
                    <p><strong>Narrator(s): </strong><?= $book['narrator'] ?></p>
                <?php } else { ?>
                    <h1>Audiobook Title</h1>
                <?php } ?>
                <div id="book-reviews" class="column half-width float-left">   
                    <?php if(isset($book_reviews)) { ?> 
                    <h2>Reviews for this Audiobook:</h2> 
                    <ul class="reviews-container">
                        <?php foreach($book_reviews as $book_review) { ?>         
                            <li class="review-block">
                                <?php $rating = intval($book_review['rating']); //var_dump($book_review); ?>    
                                <p class="rating"><span><strong>User Rating:</strong></span>
                                <?php for($i = 1; $i <= $rating; $i++) { ?>
                                    <img src="/assets/images/filled-star-rating.png" alt="" />
                                <?php } ?></p>    
                                <p><a href="/users/view_user/<?= $book_review['user_id'] ?>"><?= $book_review['alias'] ?></a> says: <span class="darker">"<?= $book_review['description'] ?>"</span></p>
                                <p><em>Posted on <?= $book_review['created_at'] ?></em></p>
                                <?php if($book_review['user_id'] == $this->session->userdata('id')) { ?>
                                    <p><a class='delete' href='/reviews/destroy_review/<?= $book_review['review_id'] ?>'>Delete Review</a></p>
                                <?php } ?>
                            </li>    
                        <?php } ?>
                    </ul>
                    <?php } elseif(!isset($book_review)) { echo "<p>There are no recent reviews.</p>"; } ?>           
                </div>
                <div class="column half-width float-right">
                    <h2>Add a Review:</h2>
                    <div class="form-container">
                        <form class="clearfix full-width" action="/reviews/create_review/<?= $book['id'] ?>" method="post">
                            <p>
                                <label>Review <span>*</span>:</label> 
                                <textarea name="description"></textarea>
                            </p>
                            <p>
                                <label>Rating <span>*</span>:</label> 
                                <input type="number" name="rating" min="1" max="5">
                                (from 1 to 5)
                            </p>
                            <button class="submit" type='submit'>Add Review</button>
                        </form>
                        <?php //} ?>
                    </div>
                    <?php //} ?>
                </div>    
            </div>  
        </div>    
    </body>
</html>