<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Dashboard, GoodListens | Coding Dojo | Red Belt Reviewer</title>
        <link rel="stylesheet" href="/assets/css/style.css">
    </head>
    <body>
        <div id="header" class="clearfix">
            <h2 id="logo" class="float-left display-inline-block vertical-align-middle"><a href="/">GoodListens</a></h2>
            <ul class="float-right display-inline-block vertical-align-middle">
                <?php $thisUser = $this->session->userdata('id'); ?> 
                <li><a href='/users/view_profile/<?= $thisUser ?>'>View Profile</a></li>
                <li><a href="/books/index">Add New Audiobook and Review</a></li>
                <li class="last"><a href="/users/logout_user">Logout</a></li>
            </ul>
            <div class="clearfix"></div>
        </div>
        <div id="main" class="padding-top-twenty">
            <div class="row padding-bottom-forty clearfix">
                
                <?php if(NULL !== $this->session->userdata('alias')) { ?>
                    <h1>Welcome, <a href='/users/view_profile/<?= $thisUser ?>'><?= $this->session->userdata('alias') ?></a>!</h1>
                <?php } else { ?>
                    <h1>Weclome!</h1>
                <?php } ?>

                <?php echo $this->session->flashdata('message'); ?>
                                
                <div id="recent-reviews" class="column float-left">
                    <h2>Recent Audiobook Reviews:</h2>
                    <ul class="reviews-container">
                        <?php if(isset($recent_reviews)) { ?>
                            <?php foreach($recent_reviews as $recent_review) { ?> 
                                <li class="review-block">
                                    <h3><a href="/books/view_book_and_reviews/<?= $recent_review['book_id'] ?>"><?= $recent_review['title'] ?></a></h3>
                                    <ul>
                                     <?php //foreach($recent_review as $review) { ?>
                                        <?php $rating = intval($recent_review['rating']); ?>    
                                        <li>
                                            <p class="rating"><span><strong>User Rating:</strong></span>
                                            <?php for($i = 1; $i <= $rating; $i++) { ?>
                                                <img src="/assets/images/filled-star-rating.png" alt="" />
                                            <?php } ?></p>
                                            <p><a href="/users/view_user/<?= $recent_review['user_id'] ?>"><?= $recent_review['alias'] ?></a> says: <span class="darker">"<?= $recent_review['description'] ?>"</span></p>
                                            <p><em>Posted on <?= $recent_review['created_at'] ?></em></p>
                                        </li>    
                                    <?php //} ?>
                                    </ul>
                                </li>     
                            <?php } ?>
                        <?php } else { echo "There are no recent reviews."; } ?> 
                        <?php if($recent_review['user_id'] == $this->session->userdata('id')) {
                            echo "</p>Delete button here!</p>";
                        } ?>       
                        <!-- If this is the user's review, let them delete it -->
                        <!-- <a class="delete" href="#">Delete this Review</a> -->
                    </ul>
                </div>
                <div id="list-of-books" class="column float-right">
                    <h2>Other Audiobooks with Reviews:</h2>
                    <div>
                        <?php if(isset($all_books)) { ?>
                            <?php foreach($all_books as $book) { ?>
                                <h4><a href="/books/view_book_and_reviews/<?= $book['id'] ?>"><?= $book['title'] ?></a><h4>
                            <?php } ?>
                        <?php } else { echo "<p>There are currently no audiobooks listed or reviewed. Why not <a href='/books/index'>review one</a>?</p>"; } ?>    
                    </div>    
                </div>        
            </div>   
        </div>  
    </body>
</html>