<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Login or Register, GoodListens | Coding Dojo | Red Belt Reviewer</title>
        <link rel="stylesheet" href="/assets/css/style.css">
    </head>
    <body>
        <div id="header" class="clearfix">
            <h2 id="logo" class="float-left display-inline-block vertical-align-middle"><a href="/">GoodListens</a></h2>
            <ul class="float-right display-inline-block vertical-align-middle">
                <li class="last"><a href="/">Register or Sign In</a></li>
            </ul>
            <div class="clearfix"></div>
        </div>
        <div id="main" class="padding-top-twenty">
            <div class="row padding-bottom-forty clearfix">
                <h1 class="text-align-center">Register or Log In</h1>
                
                <?php echo validation_errors(); ?>
                <?php echo $this->session->flashdata('message'); ?>
                
                <div id="register-box" class="form-container float-left vertical-align-top">
                    <h2 class="text-align-center">New? Register for an account!</h2>
                    <form class="clearfix" action="/users/create_user" method="post">
                        <input type="hidden" name="action" value="register">
                        <p>
                            <label>Name <span>*</span>:</label> 
                            <input type="text" name="name">
                        </p>
                        <p>
                            <label>Alias <span>*</span>:</label> 
                            <input type="text" name="alias">
                        </p>
                        <p>
                            <label>Email <span>*</span>:</label> 
                            <input type="text" name="email">
                        </p>
                        <p>
                            <label>Password <span>*</span>:</label> 
                            <input type="password" name="password">
                        </p>
                        <p>
                            <label>Confirm Password <span>*</span>:</label> 
                            <input type="password" name="confirm_password">
                        </p>
                        <button class="submit" type='submit'>Register</button>
                    </form> 
                </div>
                <div id="login-box" class="form-container float-right vertical-align-top">
                    <h2 class="text-align-center">Already have an account? Sign in!</h2>
                    <form class="clearfix" action="/users/login_user" method="post">
                        <input type="hidden" name="action" value="login">
                        <p>
                            <label>Email <span>*</span>:</label> 
                            <input type="text" name="email">
                        </p>
                        <p>
                            <label>Password <span>*</span>:</label> 
                            <input type="password" name="password">
                        </p>
                        <button class="submit" type='submit'>Login</button>
                    </form> 
                </div>
            </div>       
        </div>  
    </body>
</html>