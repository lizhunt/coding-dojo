<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>User Profile, GoodListens | Coding Dojo | Red Belt Reviewer</title>
        <link rel="stylesheet" href="/assets/css/style.css">
    </head>
    <body>
        <div id="header" class="clearfix">
            <h2 id="logo" class="float-left display-inline-block vertical-align-middle"><a href="/">GoodListens</a></h2>
            <ul class="float-right display-inline-block">
                <li><a href="/">Home</a></li>
                <li><a href="/books/index">Add New Audiobook and Review</a></li>
                <li class="last"><a href="/users/logout_user">Logout</a></li>
            </ul>
            <div class="clearfix"></div>
        </div>
        <div id="main" class="padding-top-twenty">
            <div class="row padding-bottom-forty clearfix">
                <h1>GoodListens Profile</h1>
                <div class="profile">
                <?php if(isset($user)) { ?> 
                    <p><strong>Alias:</strong> <?= $user['alias'] ?></p>
                    <p><strong>Name:</strong> <?= $user['name'] ?></p>
                    <p><strong>Email:</strong> <?= $user['email'] ?></p>
                <?php } else { ?>
                    <p><strong>Alias:</strong> <?= $this->session->userdata('alias') ?></p>
                    <p><strong>Name:</strong> <?= $this->session->userdata('name') ?></p>
                    <p><strong>Email:</strong> <?= $this->session->userdata('email') ?></p>
                <?php } ?>
                <?php if(isset($books)) { ?>
                    <?php $result = count($books); ?>  
                    <p><strong>Total Reviews:</strong> <?= $result ?></p>
                <?php } ?> 
                </div>       
            </div>
            <div id="user-reviews" class="row">
                <?php if(isset($user)) { ?>    
                    <h2><?= $user['alias'] ?> posted reviews on the following Audiobooks:</h2>
                <?php } else { ?>
                    <h2>Posted reviews on the following Audiobooks:</h2>
                <?php } ?> 
                <?php if(isset($books)) { ?>
                    <?php foreach($books as $book) { ?>
                        <p><a href="/books/view_book_and_reviews/<?= $book['book_id'] ?>"><?= $book['title'] ?></a></p>
                    <?php } ?>
                <?php } else { ?>
                    <p>There have been no reviews posted by this user.</p>
                <?php } ?>
            </div>  
        </div>    
    </body>
</html>