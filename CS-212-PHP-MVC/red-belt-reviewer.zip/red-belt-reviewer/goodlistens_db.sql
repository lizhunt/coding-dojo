-- MySQL dump 10.13  Distrib 5.6.24, for osx10.8 (x86_64)
--
-- Host: 127.0.0.1    Database: goodlistens_db
-- ------------------------------------------------------
-- Server version	5.5.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `author` varchar(45) DEFAULT NULL,
  `narrator` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_books_users1_idx` (`user_id`),
  CONSTRAINT `fk_books_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (1,'The Sound and the Fury','William Faulkner','Grover Gardner','2015-11-16 21:54:55','2015-11-16 21:54:55',1),(2,'Gone Girl','Gillian Flynn','Julia Whelan, Kirby Heyborne','2015-11-16 21:58:44','2015-11-16 21:58:44',1),(3,'Jane Eyre','Charlotte Bronte','Juliet Stevenson','2015-11-17 14:43:39','2015-11-17 14:43:39',1),(4,'Pride & Prejudice','Jane Austen','Kate Reading','2015-11-17 14:46:01','2015-11-17 14:46:01',1),(5,'Creativity, Inc.','Ed Catmull, Amy Wallace','Peter Altschuler','2015-11-17 15:37:42','2015-11-17 15:37:42',2),(6,'The Hitchhiker\'s Guide to the Galaxy','Douglas Adams','Stephen Fry','2015-11-17 16:23:57','2015-11-17 16:23:57',3),(7,'Devil in the White City','Eric Larson','Scott Brick','2015-11-17 19:54:52','2015-11-17 19:54:52',1),(8,'Atonement','Ian McEwan','Jill Tanner','2015-11-17 19:58:37','2015-11-17 19:58:37',4),(9,'Bossypants','Tina Fey','Tina Fey','2015-11-17 22:20:43','2015-11-17 22:20:43',5),(10,'Slaughterhouse-Five','Kurt Vonnegut','Ethan Hawke','2015-11-18 16:39:41','2015-11-18 16:39:41',5),(11,'Great By Choice','Jim Collins, Morten T. Hanson','Jim Collins','2015-11-18 17:12:16','2015-11-18 17:12:16',8),(12,'Finnegan\'s Wake','James Joyce','Cyril Cusak','2015-11-18 19:58:59','2015-11-18 19:58:59',6),(13,'Fates and Furies','Lauren Groff','Julia Whelan','2015-11-18 20:04:51','2015-11-18 20:04:51',9),(14,'Yes Please','Amy Poehler','Amy Poehler','2015-11-18 20:15:53','2015-11-18 20:15:53',9),(15,'Lean In','Sheryl Sandberg','Test','2015-11-18 22:00:46','2015-11-18 22:00:46',10),(16,'The God Delusion','Richard Dawkins','Richard Dawkins','2015-11-19 15:47:54','2015-11-19 15:47:54',3);
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(225) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_reviews_books1_idx` (`book_id`),
  KEY `fk_reviews_users1_idx` (`user_id`),
  CONSTRAINT `fk_reviews_books1` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_reviews_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` VALUES (1,'Gardner manages to ignite an otherwise difficult yet important and profound classic. A must-listen for literature buffs and audiobook lovers alike.',5,'2015-11-16 21:54:55','2015-11-16 21:54:55',1,1),(2,'Heyborne and Whelan each perform their parts perfectly in the popular bestseller — even more gripping than you would have read it in your head!',3,'2015-11-16 21:58:44','2015-11-16 21:58:44',2,1),(3,'Stevenson\'s rendition of Jane Eyre is superb.',5,'2015-11-17 14:43:39','2015-11-17 14:43:39',3,1),(5,'Some great little nuggets in this, even if it\'s a long listen. Peter Altschuler sounds grandfather-ish sometimes, but it starts to work for you after awhile. Stick with this one, you won\'t be disappointed!',3,'2015-11-17 15:37:42','2015-11-17 15:37:42',5,2),(6,'Absolutely hilarious — I love Stephen Fry\'s narration!',5,'2015-11-17 16:23:57','2015-11-17 16:23:57',6,3),(8,'Absolutely fantastic! I highly recommend this, especially for those long summertime road trips.\"',4,'2015-11-17 19:58:37','2015-11-17 19:58:37',8,4),(12,'It is a truth universally acknowledged that a man of large fortune must be in want of a wife.',4,'2015-11-17 21:44:34','2015-11-17 21:44:34',4,4),(18,'So flippin\' funny, this woman!',5,'2015-11-17 22:20:43','2015-11-17 22:20:43',9,5),(19,'Really, really good narration! I wish this would have been around during school, I would have listened to the book instead!',5,'2015-11-18 16:39:41','2015-11-18 16:39:41',10,5),(23,'Loved it!',5,'2015-11-18 16:51:18','2015-11-18 16:51:18',6,1),(24,'Terrific. Absolutely relevant for today\'s business leaders.',4,'2015-11-18 17:12:16','2015-11-18 17:12:16',11,8),(25,'It\'s wonderful to hear Fey\'s little asides in this — if you\'ve read the book, give it a listen as well, because there\'s a lot you\'re missing!',4,'2015-11-18 17:13:44','2015-11-18 17:13:44',9,1),(31,'Yeah. Super sux.',1,'2015-11-18 19:40:27','2015-11-18 19:40:27',5,6),(32,'I want to live on the Moors.',3,'2015-11-18 19:53:08','2015-11-18 19:53:08',3,6),(33,'Holy lord, I love Joyce. This narrator is terrible, but this BOOK. o.O',4,'2015-11-18 19:58:59','2015-11-18 19:58:59',12,6),(34,'Simply put: wonderful and important.',4,'2015-11-18 20:04:51','2015-11-18 20:04:51',13,9),(35,'So much fun. I love this woman.',2,'2015-11-18 20:15:53','2015-11-18 20:15:53',14,9),(36,'Let\'s see what ID this give me.',1,'2015-11-18 20:53:54','2015-11-18 20:53:54',9,8),(37,'Excellent.',5,'2015-11-18 22:00:46','2015-11-18 22:00:46',15,10),(38,'Sux.',1,'2015-11-19 15:46:47','2015-11-19 15:46:47',13,3),(39,'The narration style is very odd and random, but the book is good.',3,'2015-11-19 15:47:54','2015-11-19 15:47:54',16,3),(48,'Not my favorite narration, but I\'ll admit that the book is pretty captivating.',3,'2015-11-19 20:19:08','2015-11-19 20:19:08',2,2);
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews_has_users`
--

DROP TABLE IF EXISTS `reviews_has_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews_has_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`review_id`,`user_id`),
  KEY `fk_reviews_has_users_users1_idx` (`user_id`),
  KEY `fk_reviews_has_users_reviews1_idx` (`review_id`),
  CONSTRAINT `fk_reviews_has_users_reviews1` FOREIGN KEY (`review_id`) REFERENCES `reviews` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_reviews_has_users_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews_has_users`
--

LOCK TABLES `reviews_has_users` WRITE;
/*!40000 ALTER TABLE `reviews_has_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews_has_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `alias` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Liz Hunt','maddyzero','liz.hunt@email.com','5f4dcc3b5aa765d61d8327deb882cf99','2015-11-16 21:51:37','2015-11-16 21:51:37'),(2,'Will Dages','wdages','will.dages@email.com','5f4dcc3b5aa765d61d8327deb882cf99','2015-11-17 15:35:26','2015-11-17 15:35:26'),(3,'Cameron Wardzala','cwardzala','cameron.wardzala@email.com','5f4dcc3b5aa765d61d8327deb882cf99','2015-11-17 16:21:08','2015-11-17 16:21:08'),(4,'Kim Sullivan','ksullivan','kim.sullivan@email.com','5f4dcc3b5aa765d61d8327deb882cf99','2015-11-17 19:56:10','2015-11-17 19:56:10'),(5,'JoAnna Gavigan','jgavigan','joanna.gavigan@email.com','5f4dcc3b5aa765d61d8327deb882cf99','2015-11-17 22:18:35','2015-11-17 22:18:35'),(6,'Jesse Corn','jcorn','jesse.corn@email.com','5f4dcc3b5aa765d61d8327deb882cf99','2015-11-18 17:05:30','2015-11-18 17:05:30'),(7,'Brittany Gonzalez','bgonzalez','brittany.gonzalez@email.com','5f4dcc3b5aa765d61d8327deb882cf99','2015-11-18 17:07:44','2015-11-18 17:07:44'),(8,'Mitch Kroll','mkroll','mitch.kroll@email.com','5f4dcc3b5aa765d61d8327deb882cf99','2015-11-18 17:08:58','2015-11-18 17:08:58'),(9,'Jamie Belardo','jbelardo','jamie.belardo@email.com','5f4dcc3b5aa765d61d8327deb882cf99','2015-11-18 20:01:27','2015-11-18 20:01:27'),(10,'Ralph Lazaro','rlazaro','ralph.lazaro@email.com','5f4dcc3b5aa765d61d8327deb882cf99','2015-11-18 21:57:51','2015-11-18 21:57:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-19 14:21:24
